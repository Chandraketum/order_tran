<?php
$pdo = new PDO('mysql:host=localhost;dbname=payninja_db', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$customerName = $_POST['customer_name'];
$products = $_POST['products'];
$quantities = $_POST['quantities'];

try {
    $pdo->beginTransaction();
 
    $stmt = $pdo->prepare("INSERT INTO orders (customer_name) VALUES (?)");
    $stmt->execute([$customerName]);
    $orderId = $pdo->lastInsertId();
 
    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_name, quantity) VALUES (?, ?, ?)");

    foreach ($products as $index => $product) {
        if (!empty($product) && $quantities[$index] > 0) {
            $stmt->execute([$orderId, $product, $quantities[$index]]);
        }
    }

    
    file_put_contents('./jobs/order_queue.txt', $orderId . PHP_EOL, FILE_APPEND);

    $pdo->commit();
    echo "Order placed successfully. ID: " . $orderId;
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Failed to place order: " . $e->getMessage();
}
?>