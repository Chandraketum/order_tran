<!Doctype>
<html>
    <head>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
 <body>
 <div class="container">
    <div class="row">
        <div class="col-md-6">
        <form action="submit_order.php" method="POST">
    <div class="form-group p-2"><input type="text"  class="form-control"  name="customer_name" placeholder="Customer Name" required></div>
    <div class="form-group p-2"><input type="text"  class="form-control" name="products[]" placeholder="Product 1 Name" required></div>
    <div class="form-group p-2"><input type="number" class="form-control"  name="quantities[]" placeholder="Quantity" required></div>
    <div class="form-group p-2"><input type="text"  class="form-control" name="products[]" placeholder="Product 2 Name"></div>
    <div class="form-group p-2"><input type="number" class="form-control"  name="quantities[]" placeholder="Quantity 2"></div>
    <div class="form-group p-2"><button type="submit" class="form-control btn-primary" name="placeorder" >Place Order</button></div>
</form>
</div>
</div>
</div>   
</body>   
</html>    