<?php
$pdo = new PDO('mysql:host=localhost;dbname=payninja_db', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$queueFile = 'order_queue.txt';

if (!file_exists($queueFile)) {
    die("No jobs in queue.");
}

$lines = file($queueFile, FILE_IGNORE_NEW_LINES);

file_put_contents($queueFile, ''); 

foreach ($lines as $orderId) {
    try {
         
        sleep(1);  
        $pdo->prepare("UPDATE orders SET status='success' WHERE order_id = ?")->execute([$orderId]);
        echo "Processed Order ID: $orderId\n";
    } catch (Exception $e) {
        echo "Failed to process order $orderId: " . $e->getMessage() . "\n";
    }
}


?>
